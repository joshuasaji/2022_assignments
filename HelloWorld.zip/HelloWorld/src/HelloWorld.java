public class HelloWorld {
    public static void main (String[] args){
        String s = "Hello world!";
        System.out.println(s);
    }
}
